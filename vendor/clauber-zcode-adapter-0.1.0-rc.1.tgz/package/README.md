# ZCode-Adapter

Shared ZCode protocol client for T3 Code and LEGION (OpenMausBot).

Status: scaffold. The v4 spike and the server-mode study are in progress. See `docs/ARCHITECTURE.md` for scope and `AGENTS.md` for how to work here.

```
pnpm install
pnpm check
```

Consumers install the built package, not `src/`. `pnpm build` emits `dist/`; `node --experimental-strip-types scripts/pack-smoke.ts` proves the packed tarball imports. Distribution options and the configuration API: `docs/contract-config.md`.
